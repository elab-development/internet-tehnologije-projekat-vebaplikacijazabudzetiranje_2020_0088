import React from "react";
import "../App.css";
import { BsPersonBadgeFill } from "react-icons/bs";
function Account() {
  return (
    <div className="envelope">
      <br />
      <h4>
        <BsPersonBadgeFill style={{ width: 100, height: 100 }} /> ssssssss
      </h4>
    </div>
  );
}

export default Account;
