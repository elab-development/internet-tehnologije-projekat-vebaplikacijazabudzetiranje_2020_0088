import React from "react";
import ContactSupport from "../components/ContactSupport";
import GoogleMaps from "../components/GoogleMaps";

const Contact = () => {
  return (
    <div>
      <ContactSupport />
    </div>
  );
};
export default Contact;
