// import React from "react";

// function InputField({ value }) {
//   return (
//     <div className={"inputContainer"}>
//       <input
//         value={value}
//         placeholder={"Enter your" + { value } + " here"}
//         onChange={(ev) => setEmail(ev.target.value)}
//         className={"inputBox"}
//       />
//       <label className="errorLabel">{emailError}</label>
//     </div>
//   );
// }

// export default InputField;
